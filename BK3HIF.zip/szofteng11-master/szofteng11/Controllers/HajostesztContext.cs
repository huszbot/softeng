﻿namespace szofteng11.Controllers
{
    internal class HajostesztContext
    {
        public object Questions { get; internal set; }
        public object Question { get; internal set; }
    }
}